document.addEventListener("DOMContentLoaded", function() {
  var now = 0;
  var turn1 = document.getElementsByClassName('b-con');
  var turn2 = document.querySelectorAll('#banner-nav li');

  var change = function(m) {
    if (m == null) m = (now+1) % turn1.length;
    turn1[m].classList.add("b-active");
    turn1[now].classList.remove("b-active");
    turn2[m].classList.add("active");
    turn2[now].classList.remove("active");
    now = m;
  }

  var timer = setInterval(function() {
    change();
  }, 2000);
}, {once: true});


var timer = null;
window.addEventListener("scroll", function(){

  if(timer === null) {
  var header = document.getElementById("header");

  if (document.documentElement.scrollTop > 100){
    header.classList.add("header-active");
  } else {
    header.classList.remove("header-active");
  }
   timer = setTimeout(function() {
     timer = null;
   }, 300);
}
});

window.addEventListener("scroll", function(){
  var backToTop = document.getElementById("backToTop");

  if (document.documentElement.scrollTop > 1000){
    backToTop.classList.add("backToTop-active");
  }
  else {
    backToTop.classList.remove("backToTop-active");
  }
});
